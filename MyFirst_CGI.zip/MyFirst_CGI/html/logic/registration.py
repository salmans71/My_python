#!C:\Users\lifegivers\AppData\Local\Programs\Python\Python37\python.exe
import pymysql
import cgi
import cgitb
cgitb.enable()
form = cgi.FieldStorage()
fname = form.getvalue('firstname')
lname = form.getvalue('lastname')
email1 = form.getvalue('email')
password = form.getvalue('psw')
repeat_pass = form.getvalue('psw-repeat')
print("Content-type:text/html\r\n\r\n")
conn = pymysql.connect(host="localhost", user="root", passwd="", db="expenses")
cur = conn.cursor()
p = [email1]
s = cur.execute("select * from myexpenses where email =%s", p)
if s != 0:
    print("<p>You already registered plz go back & sign in!!! </p>")
elif password != repeat_pass:
    print("<p>pasword not matched</p>")
else:
    cur.execute("insert into myexpenses values ('%s','%s','%s','%s')" % (fname, lname,email1, password))
    #print("<h3>Registered succesfully</h3>")
    redirectURL = "http://localhost/frontend/html/homepage.html#/"
    print('<html>')
    print(' <head>')
    print(' <meta http-equiv="refresh" content="0;url=' + str(redirectURL) + '" />')
    print(' </head>')
    print('</html>')

conn.commit()
conn.close()
#print('Content-type:text/html\n\n')

