#!C:\Users\lifegivers\AppData\Local\Programs\Python\Python37\python.exe
import cgi
import pymysql
import cgitb
cgitb.enable()
form = cgi.FieldStorage()
email1 = str(form.getvalue('email'))
psw = form.getvalue('psw')
conn = pymysql.connect(host="localhost", user="root", passwd="", db="expenses")
cur = conn.cursor()
print("Content-type:text/html\r\n\r\n")
print("")
print("<h1></h1>")
s = cur.execute("select * from myexpenses where email = '" +email1+"'")
#s = cur.execute("select email from myexpenses")
if s > 0:
    h = cur.fetchall()
    s = str(h[0][3])
    if psw == s:
        redirectURL = "http://localhost/frontend/html/homepage.html#/"
        print('<html>')
        print(' <head>')
        print(' <meta http-equiv="refresh" content="0;url=' + str(redirectURL) + '" />')
        print(' </head>')
        print('</html>')
    else:
        print("<h1>!!!!!off</h1>")
else:
    print("<h1>first go and register</h1>")

conn.commit()
conn.close()


"""

cur.execute("select email from myexpenses")
s = cur.fectall()
#s = cur.execute("select * from myxpenses where email ='" + str(em) + "'")
if len(s)>0:
    print(f"signin email is {s}")


if len(s) >0:
print("Content-type:text/html\r\n\r\n")
print("")
print(f'email is{em} and password is{pa}')

"""