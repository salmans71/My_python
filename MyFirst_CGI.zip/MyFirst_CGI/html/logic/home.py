#!C:\Users\lifegivers\AppData\Local\Programs\Python\Python37\python.exe
import cgi
import re
import cgitb
import pymysql
cgitb.enable()
form = cgi.FieldStorage()
date  = form.getvalue('date')
amount = form.getvalue('expenditure')
print("Content-type:text/html\r\n\r\n")
conn = pymysql.connect(host="localhost", user="root", passwd="", db="expenses")
cur = conn.cursor()
cur.execute("insert into homedata values ('%s',%d)" % (date, int(amount)))
print("<p> hi ur details entered succesfully</p>")
conn.commit()
conn.close()