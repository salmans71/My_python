from django.shortcuts import render, redirect
from .models import Student
from .forms import StudentForm


# Create your views here.

def insert_view(request):
    form = StudentForm()
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(request, 'files/insert.html', {'form': form})


def display(request):
    students = Student.objects.all()
    return render(request, 'files/display.html', {'students': students})


def del_record(request, id):
    students = Student.objects.get(id=id)
    students.delete()
    return redirect('/')

def update_record(request,id):
    students = Student.objects.get(id = id)
    form = StudentForm(request.POST, instance=students)
    if form.is_valid():
        form.save(commit=True)
        return redirect('/')
    return render(request,'files/update.html',{'students':students})

