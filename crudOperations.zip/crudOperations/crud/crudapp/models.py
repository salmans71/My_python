from django.db import models


# Create your models here.
class Student(models.Model):
    no = models.IntegerField()
    name = models.CharField(max_length=50)
    marks = models.IntegerField()
    address = models.CharField(max_length=300)
