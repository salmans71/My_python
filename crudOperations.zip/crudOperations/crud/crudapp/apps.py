from django.apps import AppConfig


class CrudappConfig(AppConfig):
    name = 'crudapp'
